

    <!-- Navigation -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header" align="center"><font color="#000000">USER FEEDBACK SYSTEM</font> </h1>
                
            </div>
        </div>
        <!-- /.row -->

        <!-- Intro Content -->
        <div class="row" style="margin-bottom:50px;margin-left:50px">
           
               <P>USER FEEDBACK SYSTEM : A WEB BASED SOLUTION :
                A user feedback system is a vital component of customer-centric organizations, helping them gather valuable insights, make data-driven decisions, and continuously improve their offerings to meet the evolving needs and expectations of their users or customers.
</P> 
               
            </div>
        </div>
        <!-- /.row -->

        <!-- Footer -->
     